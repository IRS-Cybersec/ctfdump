#!/bin/bash
nc -lp 4444 -c ./test.sh
