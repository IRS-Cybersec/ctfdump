#!/bin/bash
num=1001 #number of binaries
fls="$(find ! -name '*.*')" #get list of all binaries
for i in {1..30}
do  f="$(head -$((($RANDOM % $num) + 1)) <<< "$fls" | tail -1)"
    echo "for binary <$(sed 's,^./,,' <<< "$f")>,"
    echo -n "Token: "
    read #into $REPLY
    if "$f" <<< "$REPLY" | grep -q '[-]'
    then echo "You were wrong."
         exit 1
    fi
done
echo "FLAG"
